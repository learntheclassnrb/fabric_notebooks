CREATE
	OR REPLACE VIEW DX.PP_VW_CROSSWALK_DATE AS

SELECT SRC."PP GO-LIVE" AS PP_GO_LIVE
	,SRC.SEQNO
	,SRC.MSRMNT_YEAR
	,SRC.MSRMNT_YEAR_MONTH
	,ADD_MONTHS(SRC."Enrollment24Months From", 0) AS ENROLLMENT24MONTHS_FROM
	,ADD_MONTHS("TIMESTAMP" (SRC."Enrollment24Months To"), 0) AS ENROLLMENT24MONTHS_TO
	,ADD_MONTHS(SRC."Enrollment From", 0) AS ENROLLMENT_FROM
	,ADD_MONTHS("TIMESTAMP" (SRC."Enrollment To"), 0) AS ENROLLMENT_TO
	,ADD_MONTHS(SRC."Service From / Paid From All Claims", 0) AS SERVICE_FROM_PAID_FROM_ALL_CLAIMS
	,ADD_MONTHS("TIMESTAMP" (SRC."Service To  / Paid To All Claims"), 0) AS SERVICE_TO_PAID_TO_ALL_CLAIMS
	,SRC."NumOfMonths for both Enrollment / Claims" AS NUMOFMONTHS_FOR_BOTH_ENROLLMENT_CLAIMS
	,ADD_MONTHS(SRC."Service From / Paid From - Claims for CRC", 0) AS SERVICE_FROM_PAID_FROM_CLAIMS_FOR_CRC
	,ADD_MONTHS("TIMESTAMP" (SRC."Service To  / Paid To - Claims for CRC"), 0) AS SERVICE_TO_PAID_TO_CLAIMS_FOR_CRC
	,SRC."NumOfMonths for CRC ONLY Claims" AS NUMOFMONTHS_FOR_CRC_ONLY_CLAIMS
	,ADD_MONTHS("TIMESTAMP" (SRC."Service From / Paid From - Claims for ExclEvents"), 0) AS SERVICE_FROM_PAID_FROM_CLAIMS_FOR_EXCLEVENTS
	,ADD_MONTHS("TIMESTAMP" (SRC."Service To / Paid To - Claims for ExclEvents"), 0) AS SERVICE_TO_PAID_TO_CLAIMS_FOR_EXCLEVENTS
	,SRC."NumOfMonths for ExclEvents ONLY Claims" AS NUMOFMONTHS_FOR_EXCLEVENTS_ONLY_CLAIMS
FROM (
	SELECT A."PP GO-LIVE"
		,A.SEQNO
		,A.MSRMNT_YEAR
		,A.MSRMNT_YEAR_MONTH
		,A."Enrollment24Months From"
		,A."Enrollment24Months To"
		,A."Enrollment From"
		,A."Enrollment To"
		,A."Service From / Paid From All Claims"
		,A."Service To  / Paid To All Claims"
		,A."NumOfMonths for both Enrollment / Claims"
		,A."Service From / Paid From - Claims for CRC"
		,A."Service To  / Paid To - Claims for CRC"
		,A."NumOfMonths for CRC ONLY Claims"
		,A."Service From / Paid From - Claims for ExclEvents"
		,A."Service To / Paid To - Claims for ExclEvents"
		,A."NumOfMonths for ExclEvents ONLY Claims"
	FROM (
		(
			(
				SELECT IRADW_UAT.P3_ALLPHI.CDR_YR_MON_DIM.YR_MON_DK
					,IRADW_UAT.P3_ALLPHI.CDR_YR_MON_DIM.MO_OF_YR_NUM
					,CASE 
						WHEN (IRADW_UAT.P3_ALLPHI.CDR_YR_MON_DIM.YR_MON_DK >= 202408)
							THEN '202408'::"VARCHAR"
						ELSE NULL::"VARCHAR"
						END AS "PP GO-LIVE"
					,1 AS SEQNO
					,CASE 
						WHEN (
								(IRADW_UAT.P3_ALLPHI.CDR_YR_MON_DIM.YR_MON_DK >= 202501)
								AND (IRADW_UAT.P3_ALLPHI.CDR_YR_MON_DIM.YR_MON_DK <= 202505)
								)
							THEN '2024/2025'::"VARCHAR"
						ELSE '2024'::"VARCHAR"
						END AS MSRMNT_YEAR
					,IRADW_UAT.P3_ALLPHI.CDR_YR_MON_DIM.YR_MON_DK AS MSRMNT_YEAR_MONTH
					,ADD_MONTHS('2024-12-31 00:00:00'::"TIMESTAMP", - 54) AS "Enrollment From"
					,CASE 
						WHEN (IRADW_UAT.P3_ALLPHI.CDR_YR_MON_DIM.YR_MON_DK < 202501)
							THEN '2024-12-31 00:00:00'::"VARCHAR"
						ELSE '2025-12-31 00:00:00'::"VARCHAR"
						END AS "Enrollment To"
					,ADD_MONTHS('2024-12-31 00:00:00'::"TIMESTAMP", - 36) AS "Enrollment24Months From"
					,CASE 
						WHEN (IRADW_UAT.P3_ALLPHI.CDR_YR_MON_DIM.YR_MON_DK < 202501)
							THEN '2024-12-31 00:00:00'::"VARCHAR"
						ELSE '2025-12-31 00:00:00'::"VARCHAR"
						END AS "Enrollment24Months To"
					,ADD_MONTHS('2024-12-31 00:00:00'::"TIMESTAMP", - 54) AS "Service From / Paid From All Claims"
					,CASE 
						WHEN (IRADW_UAT.P3_ALLPHI.CDR_YR_MON_DIM.YR_MON_DK < 202501)
							THEN '2024-12-31 00:00:00'::"VARCHAR"
						ELSE '2025-12-31 00:00:00'::"VARCHAR"
						END AS "Service To  / Paid To All Claims"
					,ADD_MONTHS('2024-12-31 00:00:00'::"TIMESTAMP", - 120) AS "Service From / Paid From - Claims for CRC"
					,('2012-01-01 00:00:00'::"VARCHAR")::VARCHAR(19) AS "Service From / Paid From - Claims for ExclEvents"
					,CASE 
						WHEN (IRADW_UAT.P3_ALLPHI.CDR_YR_MON_DIM.YR_MON_DK < 202501)
							THEN '2024-12-31 00:00:00'::"VARCHAR"
						ELSE '2025-12-31 00:00:00'::"VARCHAR"
						END AS "Service To  / Paid To - Claims for CRC"
					,CASE 
						WHEN (IRADW_UAT.P3_ALLPHI.CDR_YR_MON_DIM.YR_MON_DK < 202501)
							THEN '2024-12-31 00:00:00'::"VARCHAR"
						ELSE '2025-12-31 00:00:00'::"VARCHAR"
						END AS "Service To / Paid To - Claims for ExclEvents"
					,CASE 
						WHEN (
								(IRADW_UAT.P3_ALLPHI.CDR_YR_MON_DIM.YR_MON_DK >= 202501)
								AND (IRADW_UAT.P3_ALLPHI.CDR_YR_MON_DIM.YR_MON_DK <= 202505)
								)
							THEN 'More than 42 months to support parallel runs'::"VARCHAR"
						ELSE '42 months prior to the measurement year'::"VARCHAR"
						END AS "NumOfMonths for both Enrollment / Claims"
					,CASE 
						WHEN (
								(IRADW_UAT.P3_ALLPHI.CDR_YR_MON_DIM.YR_MON_DK >= 202501)
								AND (IRADW_UAT.P3_ALLPHI.CDR_YR_MON_DIM.YR_MON_DK <= 202505)
								)
							THEN 'More than 108 months to support parallel runs'::"VARCHAR"
						ELSE '108 months prior to the measurement year'::"VARCHAR"
						END AS "NumOfMonths for CRC ONLY Claims"
					,('Unlimited'::"VARCHAR")::VARCHAR(9) AS "NumOfMonths for ExclEvents ONLY Claims"
				FROM IRADW_UAT.P3_ALLPHI.CDR_YR_MON_DIM
				WHERE (
						(IRADW_UAT.P3_ALLPHI.CDR_YR_MON_DIM.YR_MON_DK > 202405)
						AND (IRADW_UAT.P3_ALLPHI.CDR_YR_MON_DIM.YR_MON_DK < 202506)
						)
				)
			
			UNION ALL
			
			(
				SELECT IRADW_UAT.P3_ALLPHI.CDR_YR_MON_DIM.YR_MON_DK
					,IRADW_UAT.P3_ALLPHI.CDR_YR_MON_DIM.MO_OF_YR_NUM
					,CASE 
						WHEN (IRADW_UAT.P3_ALLPHI.CDR_YR_MON_DIM.YR_MON_DK >= 202408)
							THEN '202408'::"VARCHAR"
						ELSE NULL::"VARCHAR"
						END AS "PP GO-LIVE"
					,2 AS SEQNO
					,CASE 
						WHEN (
								(IRADW_UAT.P3_ALLPHI.CDR_YR_MON_DIM.YR_MON_DK >= 202601)
								AND (IRADW_UAT.P3_ALLPHI.CDR_YR_MON_DIM.YR_MON_DK <= 202605)
								)
							THEN '2025/2026'::"VARCHAR"
						ELSE '2025'::"VARCHAR"
						END AS MSRMNT_YEAR
					,IRADW_UAT.P3_ALLPHI.CDR_YR_MON_DIM.YR_MON_DK AS MSRMNT_YEAR_MONTH
					,ADD_MONTHS('2025-12-31 00:00:00'::"TIMESTAMP", - 54) AS "Enrollment From"
					,CASE 
						WHEN (IRADW_UAT.P3_ALLPHI.CDR_YR_MON_DIM.YR_MON_DK < 202601)
							THEN '2025-12-31 00:00:00'::"VARCHAR"
						ELSE '2026-12-31 00:00:00'::"VARCHAR"
						END AS "Enrollment To"
					,ADD_MONTHS('2025-12-31 00:00:00'::"TIMESTAMP", - 36) AS "Enrollment24Months From"
					,CASE 
						WHEN (IRADW_UAT.P3_ALLPHI.CDR_YR_MON_DIM.YR_MON_DK < 202601)
							THEN '2025-12-31 00:00:00'::"VARCHAR"
						ELSE '2026-12-31 00:00:00'::"VARCHAR"
						END AS "Enrollment24Months To"
					,ADD_MONTHS('2025-12-31 00:00:00'::"TIMESTAMP", - 54) AS "Service From / Paid From All Claims"
					,CASE 
						WHEN (IRADW_UAT.P3_ALLPHI.CDR_YR_MON_DIM.YR_MON_DK < 202601)
							THEN '2025-12-31 00:00:00'::"VARCHAR"
						ELSE '2026-12-31 00:00:00'::"VARCHAR"
						END AS "Service To  / Paid To All Claims"
					,ADD_MONTHS('2025-12-31 00:00:00'::"TIMESTAMP", - 120) AS "Service From / Paid From - Claims for CRC"
					,('2012-01-01 00:00:00'::"VARCHAR")::VARCHAR(19) AS "Service From / Paid From - Claims for ExclEvents"
					,CASE 
						WHEN (IRADW_UAT.P3_ALLPHI.CDR_YR_MON_DIM.YR_MON_DK < 202601)
							THEN '2025-12-31 00:00:00'::"VARCHAR"
						ELSE '2026-12-31 00:00:00'::"VARCHAR"
						END AS "Service To  / Paid To - Claims for CRC"
					,CASE 
						WHEN (IRADW_UAT.P3_ALLPHI.CDR_YR_MON_DIM.YR_MON_DK < 202601)
							THEN '2025-12-31 00:00:00'::"VARCHAR"
						ELSE '2026-12-31 00:00:00'::"VARCHAR"
						END AS "Service To / Paid To - Claims for ExclEvents"
					,CASE 
						WHEN (
								(IRADW_UAT.P3_ALLPHI.CDR_YR_MON_DIM.YR_MON_DK >= 202601)
								AND (IRADW_UAT.P3_ALLPHI.CDR_YR_MON_DIM.YR_MON_DK <= 202605)
								)
							THEN 'More than 42 months to support parallel runs'::"VARCHAR"
						ELSE '42 months prior to the measurement year'::"VARCHAR"
						END AS "NumOfMonths for both Enrollment / Claims"
					,CASE 
						WHEN (
								(IRADW_UAT.P3_ALLPHI.CDR_YR_MON_DIM.YR_MON_DK >= 202601)
								AND (IRADW_UAT.P3_ALLPHI.CDR_YR_MON_DIM.YR_MON_DK <= 202605)
								)
							THEN 'More than 108 months to support parallel runs'::"VARCHAR"
						ELSE '108 months prior to the measurement year'::"VARCHAR"
						END AS "NumOfMonths for CRC ONLY Claims"
					,('Unlimited'::"VARCHAR")::VARCHAR(9) AS "NumOfMonths for ExclEvents ONLY Claims"
				FROM IRADW_UAT.P3_ALLPHI.CDR_YR_MON_DIM
				WHERE (
						(IRADW_UAT.P3_ALLPHI.CDR_YR_MON_DIM.YR_MON_DK >= 202506)
						AND (IRADW_UAT.P3_ALLPHI.CDR_YR_MON_DIM.YR_MON_DK < 202606)
						)
				)
			)
		
		UNION ALL
		
		(
			SELECT IRADW_UAT.P3_ALLPHI.CDR_YR_MON_DIM.YR_MON_DK
				,IRADW_UAT.P3_ALLPHI.CDR_YR_MON_DIM.MO_OF_YR_NUM
				,CASE 
					WHEN (IRADW_UAT.P3_ALLPHI.CDR_YR_MON_DIM.YR_MON_DK >= 202408)
						THEN '202408'::"VARCHAR"
					ELSE NULL::"VARCHAR"
					END AS "PP GO-LIVE"
				,3 AS SEQNO
				,CASE 
					WHEN (
							(IRADW_UAT.P3_ALLPHI.CDR_YR_MON_DIM.YR_MON_DK >= 202701)
							AND (IRADW_UAT.P3_ALLPHI.CDR_YR_MON_DIM.YR_MON_DK <= 202705)
							)
						THEN '2026/2027'::"VARCHAR"
					ELSE '2026'::"VARCHAR"
					END AS MSRMNT_YEAR
				,IRADW_UAT.P3_ALLPHI.CDR_YR_MON_DIM.YR_MON_DK AS MSRMNT_YEAR_MONTH
				,ADD_MONTHS('2026-12-31 00:00:00'::"TIMESTAMP", - 54) AS "Enrollment From"
				,CASE 
					WHEN (IRADW_UAT.P3_ALLPHI.CDR_YR_MON_DIM.YR_MON_DK < 202701)
						THEN '2026-12-31 00:00:00'::"VARCHAR"
					ELSE '2027-12-31 00:00:00'::"VARCHAR"
					END AS "Enrollment To"
				,ADD_MONTHS('2026-12-31 00:00:00'::"TIMESTAMP", - 36) AS "Enrollment24Months From"
				,CASE 
					WHEN (IRADW_UAT.P3_ALLPHI.CDR_YR_MON_DIM.YR_MON_DK < 202701)
						THEN '2026-12-31 00:00:00'::"VARCHAR"
					ELSE '2027-12-31 00:00:00'::"VARCHAR"
					END AS "Enrollment24Months To"
				,ADD_MONTHS('2026-12-31 00:00:00'::"TIMESTAMP", - 54) AS "Service From / Paid From All Claims"
				,CASE 
					WHEN (IRADW_UAT.P3_ALLPHI.CDR_YR_MON_DIM.YR_MON_DK < 202701)
						THEN '2026-12-31 00:00:00'::"VARCHAR"
					ELSE '2027-12-31 00:00:00'::"VARCHAR"
					END AS "Service To  / Paid To All Claims"
				,ADD_MONTHS('2026-12-31 00:00:00'::"TIMESTAMP", - 120) AS "Service From / Paid From - Claims for CRC"
				,('2012-01-01 00:00:00'::"VARCHAR")::VARCHAR(19) AS "Service From / Paid From - Claims for ExclEvents"
				,CASE 
					WHEN (IRADW_UAT.P3_ALLPHI.CDR_YR_MON_DIM.YR_MON_DK < 202701)
						THEN '2026-12-31 00:00:00'::"VARCHAR"
					ELSE '2027-12-31 00:00:00'::"VARCHAR"
					END AS "Service To  / Paid To - Claims for CRC"
				,CASE 
					WHEN (IRADW_UAT.P3_ALLPHI.CDR_YR_MON_DIM.YR_MON_DK < 202701)
						THEN '2026-12-31 00:00:00'::"VARCHAR"
					ELSE '2027-12-31 00:00:00'::"VARCHAR"
					END AS "Service To / Paid To - Claims for ExclEvents"
				,CASE 
					WHEN (
							(IRADW_UAT.P3_ALLPHI.CDR_YR_MON_DIM.YR_MON_DK >= 202701)
							AND (IRADW_UAT.P3_ALLPHI.CDR_YR_MON_DIM.YR_MON_DK <= 202705)
							)
						THEN 'More than 42 months to support parallel runs'::"VARCHAR"
					ELSE '42 months prior to the measurement year'::"VARCHAR"
					END AS "NumOfMonths for both Enrollment / Claims"
				,CASE 
					WHEN (
							(IRADW_UAT.P3_ALLPHI.CDR_YR_MON_DIM.YR_MON_DK >= 202701)
							AND (IRADW_UAT.P3_ALLPHI.CDR_YR_MON_DIM.YR_MON_DK <= 202705)
							)
						THEN 'More than 108 months to support parallel runs'::"VARCHAR"
					ELSE '108 months prior to the measurement year'::"VARCHAR"
					END AS "NumOfMonths for CRC ONLY Claims"
				,('Unlimited'::"VARCHAR")::VARCHAR(9) AS "NumOfMonths for ExclEvents ONLY Claims"
			FROM IRADW_UAT.P3_ALLPHI.CDR_YR_MON_DIM
			WHERE (
					(IRADW_UAT.P3_ALLPHI.CDR_YR_MON_DIM.YR_MON_DK >= 202606)
					AND (IRADW_UAT.P3_ALLPHI.CDR_YR_MON_DIM.YR_MON_DK < 202706)
					)
			)
		) A
	ORDER BY A.SEQNO
		,A.YR_MON_DK
	) SRC;